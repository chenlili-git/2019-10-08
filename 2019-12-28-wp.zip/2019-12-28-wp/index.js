console.log(11111111);

import fn from './src/js/1.js';
console.log(fn())

import './src/css/a.css';
import './src/img/Tulips.jpg';