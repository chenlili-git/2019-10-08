const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin')
const obj = {
    mode: 'development',
    entry: { index: './index.js' },
    devServer: {
        hot:true,
        open: true,
    },
    module: {
        rules: [
            {
                test: /\.css$/,
                use: [
                    {
                        loader: 'style-loader'
                    },
                    {
                        loader: 'css-loader'
                    },
                ]
            }

        ]
    },
    plugins: [
        new HtmlWebpackPlugin({
            template: path.resolve(__dirname, './index.html'),
            filename: 'index.html'
        })
    ]
}
module.exports = obj;