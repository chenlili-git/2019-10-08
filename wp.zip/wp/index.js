console.log(11111111);

import fn from './src/1.js';
console.log(fn())

import './src/a.css';