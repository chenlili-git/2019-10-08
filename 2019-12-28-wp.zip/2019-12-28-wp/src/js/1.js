export default function fn() {
    return 5;
}